#include <HERA.h>

void HERA_main()
{
#include "HERA_nolib-test.hera"
}
