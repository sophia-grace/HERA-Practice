Just git clone this repo anywhere; you'll need gcc (or some other C compiler),
and may want to clone the HERA-libs folder too, if you want the libraries,
and make an alias named "lib" from this folder to the folder for libraries.
(e.g. "ln -s ../HERA-libs lib" in linux).

See comments at the top of HERA-C-Run about how to set environment variables
to make it run correctly (unless you've installed it in /home/courses/lib).
